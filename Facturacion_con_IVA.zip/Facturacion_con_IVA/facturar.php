<?php
// Datos del formulario
$descripcion = $_POST['descripcion'];
$cantidad = $_POST['cantidad'];
$precio = $_POST['precio'];

// Cálculos
$subtotal = $cantidad * $precio;      // precio bruto (base)
$iva = $subtotal * 0.12;              // IVA 12%
$total_con_iva = $subtotal + $iva;    // precio total de venta

// Descuento del 15% si el total con IVA supera 150 $
if ($total_con_iva > 150) {
    $aplica_descuento = true;
    $descuento = $total_con_iva * 0.15;
} else {
    $aplica_descuento = false;
    $descuento = 0;
}

$total_pagar = $total_con_iva - $descuento;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Factura</title>
</head>
<body>
    <h1>Factura</h1>
    <p>Artículo: <?php echo htmlspecialchars($descripcion); ?></p>
    <p>Cantidad: <?php echo $cantidad; ?></p>
    <p>Precio unitario: $<?php echo number_format($precio, 2); ?></p>

    <hr>
    <p>Subtotal (precio bruto): $<?php echo number_format($subtotal, 2); ?></p>
    <p>IVA (12%): $<?php echo number_format($iva, 2); ?></p>
    <p>Total con IVA: $<?php echo number_format($total_con_iva, 2); ?></p>

    <?php if ($aplica_descuento) { ?>
        <p>Descuento (15%): SÍ aplica. Monto descontado: $<?php echo number_format($descuento, 2); ?></p>
    <?php } else { ?>
        <p>Descuento (15%): NO aplica (el total con IVA no supera $150).</p>
    <?php } ?>

    <h2>Total neto a pagar: $<?php echo number_format($total_pagar, 2); ?></h2>

    <p><a href="index.html">Nueva factura</a></p>
</body>
</html>
